# Ghost Recon Wildlands — One Click P-Core Launcher

## Normal use

Double-click:

`PLAY_WILDLANDS_PCORES.vbs`

That is the normal launcher. It opens no Command Prompt or PowerShell window.

It will:

1. Find `GRW.exe` automatically from the launcher folder, a saved path, Steam libraries, or common Ubisoft Connect locations.
2. If the game cannot be found on the first run, show a file picker for `GRW.exe` and remember the selection.
3. Detect the machine's P-cores and E-cores using the Windows processor-topology API.
4. Create `GRW.exe` **suspended**.
5. Apply the P-core affinity mask **before the game begins executing**.
6. Resume the game.

No Python installation is required.

## Debug mode

If the normal launcher fails, double-click:

`PLAY_WILDLANDS_PCORES_DEBUG.cmd`

This shows the PowerShell window so errors can be inspected.

A small log is also stored at:

`%LOCALAPPDATA%\WildlandsPCoreOneClick\launcher.log`

The remembered game path is stored at:

`%LOCALAPPDATA%\WildlandsPCoreOneClick\game_path.txt`

Delete `game_path.txt` if Wildlands is moved and you want the launcher to ask for the new location.

## Notes

- Windows 10/11 only.
- Designed for normal desktop systems with fewer than 64 logical processors in one processor group.
- On a homogeneous CPU without E-cores, it keeps all cores enabled.
- No DLL injection, memory patching, game-file modification, or BIOS changes.
- If Windows reports that elevation is required, run the launcher as Administrator.
