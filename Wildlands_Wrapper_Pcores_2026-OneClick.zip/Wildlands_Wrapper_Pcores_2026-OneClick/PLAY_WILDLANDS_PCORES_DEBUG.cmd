@echo off
setlocal
title Ghost Recon Wildlands - P-Core One Click Debug
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Wildlands_OneClick.ps1"
echo.
echo Exit code: %ERRORLEVEL%
echo Log: %LOCALAPPDATA%\WildlandsPCoreOneClick\launcher.log
echo.
pause
