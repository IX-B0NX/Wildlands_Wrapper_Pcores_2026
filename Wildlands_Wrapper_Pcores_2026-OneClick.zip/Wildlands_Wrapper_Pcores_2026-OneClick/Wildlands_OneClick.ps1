# Ghost Recon Wildlands - One Click P-Core Launcher
# Windows 10/11, no Python required.
# Detects Intel hybrid P/E topology, launches GRW.exe suspended,
# applies the P-core affinity mask, then resumes the game.

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

function Show-Error([string]$Message) {
    [System.Windows.Forms.MessageBox]::Show(
        $Message,
        'Wildlands P-Core One Click',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
}

function Save-GamePath([string]$Path) {
    $cfgDir = Join-Path $env:LOCALAPPDATA 'WildlandsPCoreOneClick'
    New-Item -ItemType Directory -Force -Path $cfgDir | Out-Null
    Set-Content -LiteralPath (Join-Path $cfgDir 'game_path.txt') -Value $Path -Encoding UTF8
}

function Read-SavedGamePath {
    $cfg = Join-Path $env:LOCALAPPDATA 'WildlandsPCoreOneClick\game_path.txt'
    if (Test-Path -LiteralPath $cfg) {
        $p = (Get-Content -LiteralPath $cfg -Raw).Trim()
        if ($p -and (Test-Path -LiteralPath $p -PathType Leaf)) { return $p }
    }
    return $null
}

function Get-SteamRoots {
    $roots = New-Object System.Collections.Generic.List[string]
    $candidates = @()
    try { $candidates += (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction SilentlyContinue).SteamPath } catch {}
    try { $candidates += (Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam' -ErrorAction SilentlyContinue).InstallPath } catch {}
    try { $candidates += (Get-ItemProperty 'HKLM:\SOFTWARE\Valve\Steam' -ErrorAction SilentlyContinue).InstallPath } catch {}

    foreach ($root in $candidates) {
        if ($root -and (Test-Path -LiteralPath $root)) {
            if (-not $roots.Contains([string]$root)) { $roots.Add([string]$root) }
        }
    }

    foreach ($root in @($roots)) {
        $vdf = Join-Path $root 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) {
            foreach ($line in Get-Content -LiteralPath $vdf -ErrorAction SilentlyContinue) {
                if ($line -match '^\s*"path"\s+"(.+)"') {
                    $p = $Matches[1] -replace '\\\\','\'
                    if ((Test-Path -LiteralPath $p) -and -not $roots.Contains($p)) { $roots.Add($p) }
                }
            }
        }
    }
    return $roots
}

function Find-GRW {
    # 1. Beside this launcher (useful if copied into the game directory)
    $local = Join-Path $PSScriptRoot 'GRW.exe'
    if (Test-Path -LiteralPath $local -PathType Leaf) { return $local }

    # 2. Previously selected location
    $saved = Read-SavedGamePath
    if ($saved) { return $saved }

    # 3. Steam libraries (AppID 460930)
    foreach ($root in Get-SteamRoots) {
        $steamapps = Join-Path $root 'steamapps'
        $manifest = Join-Path $steamapps 'appmanifest_460930.acf'
        if (Test-Path -LiteralPath $manifest) {
            $installDir = $null
            foreach ($line in Get-Content -LiteralPath $manifest -ErrorAction SilentlyContinue) {
                if ($line -match '^\s*"installdir"\s+"(.+)"') { $installDir = $Matches[1]; break }
            }
            if ($installDir) {
                $p = Join-Path (Join-Path $steamapps 'common') (Join-Path $installDir 'GRW.exe')
                if (Test-Path -LiteralPath $p -PathType Leaf) { return $p }
            }
        }

        $fallback = Join-Path $steamapps 'common\Tom Clancy''s Ghost Recon Wildlands\GRW.exe'
        if (Test-Path -LiteralPath $fallback -PathType Leaf) { return $fallback }
    }

    # 4. Common Ubisoft Connect locations
    $ubiCandidates = @(
        "$env:ProgramFiles\Ubisoft\Ubisoft Game Launcher\games\Tom Clancy's Ghost Recon Wildlands\GRW.exe",
        "${env:ProgramFiles(x86)}\Ubisoft\Ubisoft Game Launcher\games\Tom Clancy's Ghost Recon Wildlands\GRW.exe",
        "C:\Games\Ubisoft\Tom Clancy's Ghost Recon Wildlands\GRW.exe"
    )
    foreach ($p in $ubiCandidates) {
        if ($p -and (Test-Path -LiteralPath $p -PathType Leaf)) { return $p }
    }

    # 5. First run fallback: ask once and remember it
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Title = 'Select Ghost Recon Wildlands - GRW.exe'
    $dlg.Filter = 'Ghost Recon Wildlands (GRW.exe)|GRW.exe|Windows executables (*.exe)|*.exe'
    $dlg.CheckFileExists = $true
    $dlg.Multiselect = $false
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        if ([IO.Path]::GetFileName($dlg.FileName) -ine 'GRW.exe') {
            throw 'The selected file is not GRW.exe.'
        }
        Save-GamePath $dlg.FileName
        return $dlg.FileName
    }
    throw 'GRW.exe was not found or selected.'
}

$cs = @'
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

public static class WildlandsPCoreLauncher
{
    const int RelationProcessorCore = 0;
    const int ErrorInsufficientBuffer = 122;
    const uint CREATE_SUSPENDED = 0x00000004;

    [StructLayout(LayoutKind.Sequential)]
    struct GROUP_AFFINITY
    {
        public UIntPtr Mask;
        public ushort Group;
        public ushort Reserved0;
        public ushort Reserved1;
        public ushort Reserved2;
    }

    [StructLayout(LayoutKind.Sequential)]
    struct PROCESSOR_RELATIONSHIP
    {
        public byte Flags;
        public byte EfficiencyClass;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public byte[] Reserved;
        public ushort GroupCount;
        public GROUP_AFFINITY GroupMask;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    struct STARTUPINFO
    {
        public uint cb;
        public string lpReserved;
        public string lpDesktop;
        public string lpTitle;
        public uint dwX;
        public uint dwY;
        public uint dwXSize;
        public uint dwYSize;
        public uint dwXCountChars;
        public uint dwYCountChars;
        public uint dwFillAttribute;
        public uint dwFlags;
        public ushort wShowWindow;
        public ushort cbReserved2;
        public IntPtr lpReserved2;
        public IntPtr hStdInput;
        public IntPtr hStdOutput;
        public IntPtr hStdError;
    }

    [StructLayout(LayoutKind.Sequential)]
    struct PROCESS_INFORMATION
    {
        public IntPtr hProcess;
        public IntPtr hThread;
        public uint dwProcessId;
        public uint dwThreadId;
    }

    class CoreInfo
    {
        public byte EfficiencyClass;
        public ushort Group;
        public ulong Mask;
        public int ThreadCount;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool GetLogicalProcessorInformationEx(int relationshipType, IntPtr buffer, ref uint returnedLength);

    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    static extern bool CreateProcessW(
        string lpApplicationName,
        string lpCommandLine,
        IntPtr lpProcessAttributes,
        IntPtr lpThreadAttributes,
        bool bInheritHandles,
        uint dwCreationFlags,
        IntPtr lpEnvironment,
        string lpCurrentDirectory,
        ref STARTUPINFO lpStartupInfo,
        out PROCESS_INFORMATION lpProcessInformation);

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool SetProcessAffinityMask(IntPtr hProcess, UIntPtr dwProcessAffinityMask);

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern uint ResumeThread(IntPtr hThread);

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool TerminateProcess(IntPtr hProcess, uint uExitCode);

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool CloseHandle(IntPtr hObject);

    static int PopCount(ulong value)
    {
        int count = 0;
        while (value != 0) { value &= value - 1; count++; }
        return count;
    }

    static List<CoreInfo> EnumerateCores()
    {
        uint needed = 0;
        GetLogicalProcessorInformationEx(RelationProcessorCore, IntPtr.Zero, ref needed);
        int err = Marshal.GetLastWin32Error();
        if (needed == 0 || err != ErrorInsufficientBuffer)
            throw new Win32Exception(err, "Unable to read CPU topology size.");

        IntPtr buffer = Marshal.AllocHGlobal((int)needed);
        try
        {
            if (!GetLogicalProcessorInformationEx(RelationProcessorCore, buffer, ref needed))
                throw new Win32Exception(Marshal.GetLastWin32Error(), "Unable to read CPU topology.");

            var cores = new List<CoreInfo>();
            long offset = 0;
            while (offset < needed)
            {
                IntPtr record = IntPtr.Add(buffer, (int)offset);
                int relationship = Marshal.ReadInt32(record, 0);
                int size = Marshal.ReadInt32(record, 4);
                if (size <= 0) throw new Exception("Invalid CPU topology record.");

                if (relationship == RelationProcessorCore)
                {
                    IntPtr relPtr = IntPtr.Add(record, 8);
                    PROCESSOR_RELATIONSHIP rel = Marshal.PtrToStructure<PROCESSOR_RELATIONSHIP>(relPtr);
                    if (rel.GroupCount != 1)
                        throw new Exception("Unsupported CPU topology: a core spans multiple processor groups.");

                    ulong mask = rel.GroupMask.Mask.ToUInt64();
                    cores.Add(new CoreInfo {
                        EfficiencyClass = rel.EfficiencyClass,
                        Group = rel.GroupMask.Group,
                        Mask = mask,
                        ThreadCount = PopCount(mask)
                    });
                }
                offset += size;
            }
            if (cores.Count == 0) throw new Exception("No CPU cores were detected.");
            return cores;
        }
        finally { Marshal.FreeHGlobal(buffer); }
    }

    static ulong ChoosePCoreMask(out int pCoreCount, out string logicalThreads)
    {
        var cores = EnumerateCores();
        List<CoreInfo> selected;
        var classes = cores.Select(c => c.EfficiencyClass).Distinct().ToList();

        if (classes.Count > 1)
        {
            byte best = classes.Max();
            selected = cores.Where(c => c.EfficiencyClass == best).ToList();
        }
        else
        {
            bool hasSmt = cores.Any(c => c.ThreadCount > 1);
            bool hasSingle = cores.Any(c => c.ThreadCount == 1);
            selected = (hasSmt && hasSingle) ? cores.Where(c => c.ThreadCount > 1).ToList() : cores;
        }

        var groups = selected.Select(c => c.Group).Distinct().ToList();
        if (groups.Count != 1)
            throw new Exception("P-cores span multiple processor groups; this launcher supports normal desktop CPUs under 64 logical processors.");

        ulong mask = 0;
        foreach (var c in selected) mask |= c.Mask;
        if (mask == 0) throw new Exception("The selected P-core affinity mask is empty.");

        pCoreCount = selected.Count;
        var logical = new List<int>();
        for (int i = 0; i < 64; i++) if ((mask & (1UL << i)) != 0) logical.Add(i);
        logicalThreads = String.Join(",", logical);
        return mask;
    }

    public static string Launch(string exePath)
    {
        if (String.IsNullOrWhiteSpace(exePath) || !File.Exists(exePath))
            throw new FileNotFoundException("GRW.exe was not found.", exePath);

        int pCoreCount;
        string logicalThreads;
        ulong mask = ChoosePCoreMask(out pCoreCount, out logicalThreads);

        STARTUPINFO si = new STARTUPINFO();
        si.cb = (uint)Marshal.SizeOf(typeof(STARTUPINFO));
        PROCESS_INFORMATION pi;
        string cmd = "\"" + Path.GetFullPath(exePath) + "\"";

        bool ok = CreateProcessW(
            Path.GetFullPath(exePath), cmd,
            IntPtr.Zero, IntPtr.Zero, false,
            CREATE_SUSPENDED,
            IntPtr.Zero,
            Path.GetDirectoryName(Path.GetFullPath(exePath)),
            ref si, out pi);

        if (!ok)
        {
            int error = Marshal.GetLastWin32Error();
            if (error == 740) throw new Exception("Windows requires administrator elevation. Right-click the launcher and choose Run as administrator.");
            throw new Win32Exception(error, "CreateProcessW failed.");
        }

        bool resumed = false;
        try
        {
            if (!SetProcessAffinityMask(pi.hProcess, new UIntPtr(mask)))
                throw new Win32Exception(Marshal.GetLastWin32Error(), "SetProcessAffinityMask failed.");

            uint result = ResumeThread(pi.hThread);
            if (result == 0xFFFFFFFF)
                throw new Win32Exception(Marshal.GetLastWin32Error(), "ResumeThread failed.");
            resumed = true;

            return String.Format("PID={0}; P-cores={1}; Threads={2}; Mask=0x{3:X}", pi.dwProcessId, pCoreCount, logicalThreads, mask);
        }
        catch
        {
            if (!resumed) TerminateProcess(pi.hProcess, 1);
            throw;
        }
        finally
        {
            CloseHandle(pi.hThread);
            CloseHandle(pi.hProcess);
        }
    }
}
'@

try {
    Add-Type -TypeDefinition $cs -Language CSharp
    $game = Find-GRW
    Save-GamePath $game
    $result = [WildlandsPCoreLauncher]::Launch($game)

    # Write a tiny diagnostic log without interrupting the one-click flow.
    $logDir = Join-Path $env:LOCALAPPDATA 'WildlandsPCoreOneClick'
    New-Item -ItemType Directory -Force -Path $logDir | Out-Null
    Add-Content -LiteralPath (Join-Path $logDir 'launcher.log') -Value "$(Get-Date -Format s) | $game | $result"
    exit 0
}
catch {
    try {
        $logDir = Join-Path $env:LOCALAPPDATA 'WildlandsPCoreOneClick'
        New-Item -ItemType Directory -Force -Path $logDir | Out-Null
        Add-Content -LiteralPath (Join-Path $logDir 'launcher.log') -Value "$(Get-Date -Format s) | ERROR | $($_.Exception.Message)"
    } catch {}
    Show-Error ("Could not launch Wildlands on P-cores only.`r`n`r`n" + $_.Exception.Message + "`r`n`r`nLog: %LOCALAPPDATA%\WildlandsPCoreOneClick\launcher.log")
    exit 1
}
