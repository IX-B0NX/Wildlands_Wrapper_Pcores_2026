Option Explicit
Dim shell, fso, base, script, cmd
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
script = fso.BuildPath(base, "Wildlands_OneClick.ps1")
If Not fso.FileExists(script) Then
    MsgBox "Wildlands_OneClick.ps1 was not found next to this launcher.", 16, "Wildlands P-Core One Click"
    WScript.Quit 1
End If
cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & script & """"
shell.Run cmd, 0, False
